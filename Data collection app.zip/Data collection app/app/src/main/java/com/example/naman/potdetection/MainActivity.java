package com.example.naman.potdetection;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.app.Activity;
import android.os.Environment;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Button;

import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.widget.Toast;

import java.sql.Timestamp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements SensorEventListener, LocationListener {
    private TextView xText, yText, zText;
    private Sensor mySensor;
    private SensorManager SM;
    final int REQUEST_CODE_ASK_PERMISSIONS = 123;
    private String s = "output.txt";
    private String entry;
    public boolean stateSave;
    private Date x = new Date();
    private SimpleDateFormat df = new SimpleDateFormat("ddmmyyyyhhmmss");
    private TextView textView;
    private LocationManager locationManager;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkPermissions();

//        checkPermissions();
        stateSave = false;

        //Our Sensor Manager
        SM = (SensorManager) getSystemService(SENSOR_SERVICE);

        //Accelerometer Sensor
        mySensor = SM.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);

        //Register sensor listener
        SM.registerListener(this, mySensor, SensorManager.SENSOR_DELAY_NORMAL);
        xText = (TextView) findViewById(R.id.xText);
        yText = (TextView) findViewById(R.id.yText);
        zText = (TextView) findViewById(R.id.zText);
        textView = (TextView) findViewById(R.id.id_textView);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Location location = locationManager.getLastKnownLocation(locationManager.NETWORK_PROVIDER);
        onLocationChanged(location);
    }
    @Override
    public void onSensorChanged(SensorEvent event){
        if(stateSave == true) {
            xText.setText("X    " + event.values[0]);
            yText.setText("Y    " + event.values[1]);
            zText.setText("Z    " + event.values[2]);

            entry = xText.getText().toString().substring(5) + "," + yText.getText().toString().substring(5) + "," + zText.getText().toString().substring(5)+","+textView.getText().toString() + "\n";
        }
        if(stateSave == true) {
            if (isExternalStorageWritable() && toCheckPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                File textfile = new File(Environment.getExternalStorageDirectory(), "output"+df.format(x)+".csv");
//                stateSave2=1;
                try
                {
                    FileOutputStream fos = new FileOutputStream(textfile, true);
                    fos.write(entry.getBytes());
                    fos.close();
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        }
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        //Not in use
    }
public void writeFile(View v) {

        if(stateSave == false){
            stateSave=true;
            Button button= (Button) findViewById(R.id.button0);
                    button.setText("STOP");
        }
        else
        {
            stateSave = false;
            Button button= (Button) findViewById(R.id.button0);
            button.setText("START");
            x=new Date();
        }
    }
    private boolean isExternalStorageWritable() {
        if(Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())){
            Log.i("State", "Yes,its Writable");
            return true;
        }
        else
            return false;
    }
    public boolean toCheckPermission(String permission){
        int check = ContextCompat.checkSelfPermission(this,permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }

    @Override
    public void onLocationChanged(Location location) {
        double longitude=location.getLongitude();
        double latitude=location.getLatitude();
        textView.setText(longitude+","+latitude);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkPermissions() {
        int hasWriteContactsPermission = checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int hasLocationAccessPermission = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION);
//        int hasLocationAccessPermission = checkPermission(Manifest.permission.)
        if (hasWriteContactsPermission != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CODE_ASK_PERMISSIONS);

        }
        else if(hasLocationAccessPermission != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE_ASK_PERMISSIONS);

        }


        Toast.makeText(getBaseContext(), "All permissions granted", Toast.LENGTH_LONG).show();
    }
}