package com.example.msbhakuni.sensor_demo;

import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;

import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private static final String TAG = "MainActivity";
    private SensorManager sensorManager;
    Sensor accelerometer;


    TextView xValue, yValue, zValue;
    MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        xValue = (TextView) findViewById(R.id.textViewX);
        yValue = (TextView) findViewById(R.id.textViewY);
        zValue = (TextView) findViewById(R.id.textViewZ);

        mediaPlayer = MediaPlayer.create(this,R.raw.beep1);

        Log.d(TAG, "onCreate: Initializing sensor services ");
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        sensorManager.registerListener(MainActivity.this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        Log.d(TAG, "onCreate: Registered accelerometer listener ");

    }

    @Override
    public void  onAccuracyChanged(Sensor sensor ,int i){

    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        Log.d(TAG, "onSensorChanged: X: " + sensorEvent.values[0] + "Y : " + sensorEvent.values[1] + "Z: " + sensorEvent.values[2]);

        xValue.setText("x : " + sensorEvent.values[0]);
        yValue.setText("y : " + sensorEvent.values[1]);
        zValue.setText("z : " + sensorEvent.values[2]);
        if(sensorEvent.values[2]>20 || sensorEvent.values[1]>20 || sensorEvent.values[0]>20  ) {
            mediaPlayer.start();
            Toast.makeText(getApplicationContext(),"PotHole Detected", Toast.LENGTH_SHORT).show();


        }

    }



}
